//dades
export const dades = [
    {
        nick:"carlos",
        pass: "1234",
        avatar: "avatar1.png",
        punts: 0,
        dataRegistre: '2022/10/10',
        dataNeixement: '1970/10/10',
        partides: 
        [
            {
                partidaID :"2022_10_13_15:20:52:18",
                punts: 150
            }, 
            {
                partidaID: "2022_10_13_15:25:50:45" ,
                punts: 118
            } 
        ]

    },
    {
        nick:"pepe",
        pass: "0000",
        avatar: "avatar2.png",
        punts: 0,
        dataRegistre: '2022/10/09',
        dataNeixement: '1973/04/13', 
        partides: [
            {
                partidaID :"2022_10_13_15:20:54:18",
                punts: 15
            }, 
            {
                partidaID: "2022_10_13_15:25:55:45" ,
                punts: 200
            } 
        ]
    }
]
